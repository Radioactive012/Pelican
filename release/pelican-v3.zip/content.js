"use strict";
(() => {
  // src/adapters/messageObserver.ts
  function observeRenderedUserMessages(getNodes, getConversationId, callback, options) {
    const debounceMs = options?.debounceMs ?? 600;
    const seen = /* @__PURE__ */ new WeakSet();
    const pending = /* @__PURE__ */ new Map();
    let conversationId = getConversationId();
    const cancelPending = () => {
      for (const item of pending.values()) clearTimeout(item.timer);
      pending.clear();
    };
    const seedExisting = () => {
      for (const node of getNodes()) seen.add(node);
    };
    seedExisting();
    const scan = () => {
      const nextId = getConversationId();
      if (nextId !== conversationId) {
        const placeholderBecameReal = conversationId.includes("-new-") && !nextId.includes("-new-");
        conversationId = nextId;
        if (!placeholderBecameReal) {
          cancelPending();
        }
      }
      for (const node of getNodes()) {
        if (seen.has(node)) continue;
        const text = (node.textContent || "").trim();
        if (!text) continue;
        const prior = pending.get(node);
        if (prior?.text === text) continue;
        if (prior) clearTimeout(prior.timer);
        const timer = setTimeout(() => {
          pending.delete(node);
          if (!node.isConnected || seen.has(node)) return;
          const finalText = (node.textContent || "").trim();
          if (finalText !== text) {
            scan();
            return;
          }
          seen.add(node);
          callback({ text: finalText, conversationId: getConversationId() });
        }, debounceMs);
        pending.set(node, { text, timer });
      }
    };
    const observer = new MutationObserver(scan);
    if (typeof document !== "undefined" && document.body) {
      observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    }
    const onLocationChange = () => {
      scan();
    };
    if (typeof window !== "undefined") {
      window.addEventListener("popstate", onLocationChange);
    }
    const origPushState = typeof window !== "undefined" && window.history?.pushState ? window.history.pushState : null;
    const origReplaceState = typeof window !== "undefined" && window.history?.replaceState ? window.history.replaceState : null;
    if (origPushState && window.history) {
      window.history.pushState = function(...args) {
        const res = origPushState.apply(this, args);
        onLocationChange();
        return res;
      };
    }
    if (origReplaceState && window.history) {
      window.history.replaceState = function(...args) {
        const res = origReplaceState.apply(this, args);
        onLocationChange();
        return res;
      };
    }
    return () => {
      observer.disconnect();
      if (typeof window !== "undefined") {
        window.removeEventListener("popstate", onLocationChange);
        if (origPushState && window.history) {
          window.history.pushState = origPushState;
        }
        if (origReplaceState && window.history) {
          window.history.replaceState = origReplaceState;
        }
      }
      cancelPending();
    };
  }

  // src/adapters/composer.ts
  function readComposer(composer) {
    if (!composer) return "";
    const isTextarea = typeof HTMLTextAreaElement !== "undefined" && composer instanceof HTMLTextAreaElement || composer.tagName === "TEXTAREA";
    const isInput = typeof HTMLInputElement !== "undefined" && composer instanceof HTMLInputElement || composer.tagName === "INPUT";
    if (isTextarea || isInput) return composer.value || "";
    return composer.innerText || composer.textContent || "";
  }
  function writeComposer(composer, text) {
    if (!composer) return false;
    const isTextarea = typeof HTMLTextAreaElement !== "undefined" && composer instanceof HTMLTextAreaElement || composer.tagName === "TEXTAREA";
    const isInput = typeof HTMLInputElement !== "undefined" && composer instanceof HTMLInputElement || composer.tagName === "INPUT";
    if (isTextarea || isInput) {
      const target = composer;
      const proto = isTextarea ? typeof HTMLTextAreaElement !== "undefined" ? HTMLTextAreaElement.prototype : Object.getPrototypeOf(target) : typeof HTMLInputElement !== "undefined" ? HTMLInputElement.prototype : Object.getPrototypeOf(target);
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (setter) setter.call(target, text);
      else target.value = text;
      target.dispatchEvent(new Event("input", { bubbles: true }));
      target.dispatchEvent(new Event("change", { bubbles: true }));
      return target.value === text;
    }
    if (typeof composer.focus === "function") {
      composer.focus();
    }
    if (typeof window !== "undefined" && typeof window.getSelection === "function" && typeof document !== "undefined" && typeof document.createRange === "function") {
      const selection = window.getSelection();
      if (selection) {
        const range = document.createRange();
        range.selectNodeContents(composer);
        selection.removeAllRanges();
        selection.addRange(range);
      }
    }
    const inserted = typeof document !== "undefined" && typeof document.execCommand === "function" && document.execCommand("insertText", false, text);
    if (!inserted || readComposer(composer) !== text) {
      composer.textContent = text;
      if (typeof InputEvent !== "undefined") {
        composer.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
      } else {
        composer.dispatchEvent(new Event("input", { bubbles: true }));
      }
    }
    return readComposer(composer) === text;
  }

  // src/adapters/chatgpt.ts
  var ChatGPTAdapter = class {
    name = "chatgpt";
    displayName = "ChatGPT";
    newChatSessionId = null;
    matches(url) {
      return /chatgpt\.com|chat\.openai\.com/.test(url);
    }
    getConversationId() {
      const match = window.location.pathname.match(/\/c\/([a-zA-Z0-9_-]+)/);
      if (match && match[1]) {
        this.newChatSessionId = null;
        return match[1];
      }
      if (!this.newChatSessionId) {
        this.newChatSessionId = `chatgpt-new-${Math.random().toString(36).slice(2, 10)}`;
      }
      return this.newChatSessionId;
    }
    resetNewChatSession() {
      this.newChatSessionId = `chatgpt-new-${Math.random().toString(36).slice(2, 10)}`;
    }
    getComposer() {
      return document.querySelector("#prompt-textarea") || document.querySelector('textarea[data-id="root"]') || document.querySelector("form textarea") || document.querySelector('div[contenteditable="true"]');
    }
    getComposerDraft() {
      return readComposer(this.getComposer());
    }
    setComposerDraft(text) {
      writeComposer(this.getComposer(), text);
    }
    attachUseMemoryButton(button) {
      const composer = this.getComposer();
      if (!composer) return false;
      const form = composer.closest("form") || composer.parentElement;
      if (!form) return false;
      if (form.querySelector(".context-passport-action-container")) {
        return true;
      }
      const container = document.createElement("div");
      container.className = "context-passport-action-container";
      container.style.display = "inline-flex";
      container.style.alignItems = "center";
      container.style.margin = "4px 6px";
      container.appendChild(button);
      const sendBtn = form.querySelector('button[data-testid="send-button"]') || form.querySelector('button[aria-label="Send prompt"]') || form.querySelector('button[type="submit"]');
      if (sendBtn && sendBtn.parentElement) {
        sendBtn.parentElement.insertBefore(container, sendBtn);
      } else {
        form.appendChild(container);
      }
      return true;
    }
    observeUserMessages(callback, options) {
      return observeRenderedUserMessages(
        () => {
          const nodes = Array.from(document.querySelectorAll('[data-message-author-role="user"]')).filter((node) => !node.closest('[data-message-author-role="assistant"]'));
          return nodes.filter((node) => !nodes.some((other) => other !== node && other.contains(node)));
        },
        () => this.getConversationId(),
        callback,
        options
      );
    }
  };

  // src/adapters/claude.ts
  var ClaudeAdapter = class {
    name = "claude";
    displayName = "Claude";
    newChatSessionId = null;
    matches(url) {
      return /claude\.ai/.test(url);
    }
    getConversationId() {
      const match = window.location.pathname.match(/\/chat\/([a-zA-Z0-9_-]+)/);
      if (match && match[1]) {
        this.newChatSessionId = null;
        return match[1];
      }
      if (!this.newChatSessionId) {
        this.newChatSessionId = `claude-new-${Math.random().toString(36).slice(2, 10)}`;
      }
      return this.newChatSessionId;
    }
    resetNewChatSession() {
      this.newChatSessionId = `claude-new-${Math.random().toString(36).slice(2, 10)}`;
    }
    getComposer() {
      return document.querySelector('div[contenteditable="true"].ProseMirror') || document.querySelector('fieldset div[contenteditable="true"]') || document.querySelector('div[contenteditable="true"]') || document.querySelector("textarea");
    }
    getComposerDraft() {
      return readComposer(this.getComposer());
    }
    setComposerDraft(text) {
      writeComposer(this.getComposer(), text);
    }
    attachUseMemoryButton(button) {
      const composer = this.getComposer();
      if (!composer) return false;
      const parentContainer = composer.closest("fieldset") || composer.parentElement;
      if (!parentContainer) return false;
      if (parentContainer.querySelector(".context-passport-action-container")) {
        return true;
      }
      const container = document.createElement("div");
      container.className = "context-passport-action-container";
      container.style.display = "inline-flex";
      container.style.alignItems = "center";
      container.style.margin = "4px 6px";
      container.appendChild(button);
      const sendBtn = parentContainer.querySelector('button[aria-label*="Send"]') || parentContainer.querySelector('button[type="submit"]');
      if (sendBtn && sendBtn.parentElement) {
        sendBtn.parentElement.insertBefore(container, sendBtn);
      } else {
        parentContainer.appendChild(container);
      }
      return true;
    }
    observeUserMessages(callback, options) {
      return observeRenderedUserMessages(
        () => {
          const nodes = Array.from(document.querySelectorAll('[data-testid="user-message"], .font-user-message')).filter((node) => !node.closest('[data-testid="assistant-message"], .font-claude-message, [data-is-streaming="true"]'));
          return nodes.filter((node) => !nodes.some((other) => other !== node && other.contains(node)));
        },
        () => this.getConversationId(),
        callback,
        options
      );
    }
  };

  // src/adapters/gemini.ts
  var GeminiAdapter = class {
    name = "gemini";
    displayName = "Gemini";
    newChatSessionId = null;
    matches(url) {
      return /gemini\.google\.com/.test(url);
    }
    getConversationId() {
      const match = window.location.pathname.match(/\/app\/([a-zA-Z0-9_-]+)/);
      if (match && match[1]) {
        this.newChatSessionId = null;
        return match[1];
      }
      if (!this.newChatSessionId) {
        this.newChatSessionId = `gemini-new-${Math.random().toString(36).slice(2, 10)}`;
      }
      return this.newChatSessionId;
    }
    resetNewChatSession() {
      this.newChatSessionId = `gemini-new-${Math.random().toString(36).slice(2, 10)}`;
    }
    getComposer() {
      return document.querySelector("rich-textarea .ql-editor") || document.querySelector('div[contenteditable="true"].ql-editor') || document.querySelector('rich-textarea div[contenteditable="true"]') || document.querySelector("textarea");
    }
    getComposerDraft() {
      return readComposer(this.getComposer());
    }
    setComposerDraft(text) {
      writeComposer(this.getComposer(), text);
    }
    attachUseMemoryButton(button) {
      const composer = this.getComposer();
      if (!composer) return false;
      const parentBar = composer.closest(".input-area-container") || composer.closest("form") || composer.parentElement;
      if (!parentBar) return false;
      if (parentBar.querySelector(".context-passport-action-container")) {
        return true;
      }
      const container = document.createElement("div");
      container.className = "context-passport-action-container";
      container.style.display = "inline-flex";
      container.style.alignItems = "center";
      container.style.margin = "4px 6px";
      container.appendChild(button);
      const sendBtn = parentBar.querySelector("button.send-button") || parentBar.querySelector('button[aria-label*="Send message"]') || parentBar.querySelector("button[mat-icon-button]");
      if (sendBtn && sendBtn.parentElement) {
        sendBtn.parentElement.insertBefore(container, sendBtn);
      } else {
        parentBar.appendChild(container);
      }
      return true;
    }
    observeUserMessages(callback, options) {
      return observeRenderedUserMessages(
        () => {
          const primary = Array.from(document.querySelectorAll("user-query"));
          const nodes = primary.length ? primary : Array.from(document.querySelectorAll('div[data-sender="user"], .user-query-container, .user-query-text'));
          return nodes.filter((node) => !node.closest('model-response, .model-response-container, [data-sender="model"], response-container')).filter((node) => !nodes.some((other) => other !== node && other.contains(node)));
        },
        () => this.getConversationId(),
        callback,
        options
      );
    }
  };

  // src/adapters/index.ts
  function getMatchingAdapter(url = window.location.href) {
    const adapters = [
      new ChatGPTAdapter(),
      new ClaudeAdapter(),
      new GeminiAdapter()
    ];
    for (const adapter of adapters) {
      if (adapter.matches(url)) {
        return adapter;
      }
    }
    return null;
  }

  // src/core/storage.ts
  var DEFAULT_BACKEND_URL = true ? "http://127.0.0.1:8000" : "http://127.0.0.1:8000";
  var DEFAULT_SETTINGS = {
    // Capture is OFF by default across all sites
    capture_chatgpt: false,
    capture_claude: false,
    capture_gemini: false,
    backend_url: DEFAULT_BACKEND_URL,
    auth_token: "",
    refresh_token: "",
    user_email: ""
  };
  var memoryStore = { ...DEFAULT_SETTINGS };
  function packagedBackendUrl() {
    const url = typeof chrome !== "undefined" && chrome.runtime?.getManifest?.().homepage_url;
    return typeof url === "string" && /^https:\/\//.test(url) ? url.replace(/\/+$/, "") : DEFAULT_BACKEND_URL;
  }
  function hasChromeStorage() {
    return typeof chrome !== "undefined" && !!chrome.storage && !!chrome.storage.local;
  }
  async function getAllSettings() {
    if (hasChromeStorage()) {
      return new Promise((resolve) => {
        chrome.storage.local.get(null, (result) => {
          resolve({
            ...DEFAULT_SETTINGS,
            backend_url: packagedBackendUrl(),
            ...result
          });
        });
      });
    }
    return { ...DEFAULT_SETTINGS, ...memoryStore };
  }

  // src/core/api.ts
  var ContextPassportApiClient = class {
    backendUrl;
    token;
    constructor(backendUrl = DEFAULT_BACKEND_URL, token = "") {
      this.backendUrl = backendUrl.replace(/\/+$/, "");
      this.token = token.trim().replace(/^Bearer\s+/i, "");
    }
    setToken(token) {
      this.token = token.trim().replace(/^Bearer\s+/i, "");
    }
    setBackendUrl(url) {
      this.backendUrl = url.replace(/\/+$/, "");
    }
    getHeaders() {
      const headers = {
        "Content-Type": "application/json"
      };
      if (this.token) {
        headers["Authorization"] = `Bearer ${this.token}`;
      }
      return headers;
    }
    async checkHealth() {
      try {
        const res = await fetch(`${this.backendUrl}/health`);
        if (!res.ok) return { ok: false, status: `HTTP ${res.status}` };
        const data = await res.json();
        return { ok: true, status: data.status, version: data.version };
      } catch (err) {
        return { ok: false, status: err.message || "Offline" };
      }
    }
    async checkReady() {
      try {
        const res = await fetch(`${this.backendUrl}/ready`);
        const data = await res.json();
        return { ready: data.status === "ready", missing: data.missing };
      } catch {
        return { ready: false, missing: ["Server Unreachable"] };
      }
    }
    async login(email, password) {
      const res = await fetch(`${this.backendUrl}/api/v1/auth/token`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ detail: "Authentication failed" }));
        throw new Error(err.detail || "Authentication failed");
      }
      const data = await res.json();
      this.token = data.access_token;
      if (data.refresh_token && typeof chrome !== "undefined" && chrome.storage?.local) {
        try {
          chrome.storage.local.set({ refresh_token: data.refresh_token });
        } catch {
        }
      }
      return data.access_token;
    }
    async refreshToken(refreshToken) {
      const res = await fetch(`${this.backendUrl}/api/v1/auth/refresh`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: refreshToken })
      });
      if (!res.ok) {
        throw new Error("Failed to refresh token");
      }
      const data = await res.json();
      this.token = data.access_token;
      if (typeof chrome !== "undefined" && chrome.storage?.local) {
        try {
          chrome.storage.local.set({
            auth_token: data.access_token,
            ...data.refresh_token ? { refresh_token: data.refresh_token } : {}
          });
        } catch {
        }
      }
      return data.access_token;
    }
    async ingestMessage(payload) {
      const res = await fetch(`${this.backendUrl}/api/v1/messages/ingest`, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify({
          conversation_id: payload.conversation_id,
          text: payload.text,
          role: payload.role || "user",
          is_extension_context: Boolean(payload.is_extension_context),
          event_id: payload.event_id,
          source_site: payload.source_site
        })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
        throw new Error(err.detail || `Ingest failed with status ${res.status}`);
      }
      return res.json();
    }
    async queryMemories(query, maxGeneral = 3) {
      const res = await fetch(`${this.backendUrl}/api/v1/memories/query`, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify({
          query,
          max_general: maxGeneral
        })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
        throw new Error(err.detail || `Memory query failed with status ${res.status}`);
      }
      return res.json();
    }
    async getAllMemories() {
      const res = await fetch(`${this.backendUrl}/api/v1/memories`, {
        method: "GET",
        headers: this.getHeaders()
      });
      if (!res.ok) {
        throw new Error(`Failed to load memories: HTTP ${res.status}`);
      }
      return res.json();
    }
    async blockMemory(memoryId) {
      const res = await fetch(`${this.backendUrl}/api/v1/memories/${encodeURIComponent(memoryId)}/block`, {
        method: "POST",
        headers: this.getHeaders()
      });
      return res.ok;
    }
    async updateMemory(memoryId, text) {
      const res = await fetch(`${this.backendUrl}/api/v1/memories/${encodeURIComponent(memoryId)}`, {
        method: "PUT",
        headers: this.getHeaders(),
        body: JSON.stringify({ text })
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
        throw new Error(err.detail || `Memory update failed: HTTP ${res.status}`);
      }
      return res.json();
    }
    async deleteMemory(memoryId) {
      const res = await fetch(`${this.backendUrl}/api/v1/memories/${encodeURIComponent(memoryId)}`, {
        method: "DELETE",
        headers: this.getHeaders()
      });
      return res.ok;
    }
    async getPreferences() {
      const res = await fetch(`${this.backendUrl}/api/v1/preferences`, {
        method: "GET",
        headers: this.getHeaders()
      });
      if (!res.ok) {
        throw new Error(`Failed to load preferences: HTTP ${res.status}`);
      }
      return res.json();
    }
    async updatePreference(preferenceId, newText) {
      const res = await fetch(`${this.backendUrl}/api/v1/preferences/${encodeURIComponent(preferenceId)}`, {
        method: "PUT",
        headers: this.getHeaders(),
        body: JSON.stringify({ preference_text: newText })
      });
      if (!res.ok) {
        throw new Error(`Failed to update preference: HTTP ${res.status}`);
      }
      return res.json();
    }
    async removePreferenceEvidence(preferenceId, observationId) {
      const res = await fetch(`${this.backendUrl}/api/v1/preferences/${encodeURIComponent(preferenceId)}/observations/${encodeURIComponent(observationId)}`, {
        method: "DELETE",
        headers: this.getHeaders()
      });
      if (!res.ok) throw new Error(`Could not remove evidence: HTTP ${res.status}`);
      return (await res.json()).ok === true;
    }
    async blockPreference(preferenceId) {
      const res = await fetch(`${this.backendUrl}/api/v1/preferences/${encodeURIComponent(preferenceId)}/block`, {
        method: "POST",
        headers: this.getHeaders()
      });
      if (!res.ok) throw new Error(`Could not block preference: HTTP ${res.status}`);
      return (await res.json()).ok === true;
    }
    async forgetPreference(preferenceId) {
      const res = await fetch(`${this.backendUrl}/api/v1/preferences/${encodeURIComponent(preferenceId)}`, {
        method: "DELETE",
        headers: this.getHeaders()
      });
      if (!res.ok) throw new Error(`Could not forget preference: HTTP ${res.status}`);
      return (await res.json()).ok === true;
    }
  };

  // src/core/injection.ts
  var INJECTION_START_MARKER = "[Context Passport: Memory]";
  var INJECTION_END_MARKER = "[/Context Passport]";
  var INJECTION_BLOCK_REGEX = /\[Context Passport:[^\]]*\][\s\S]*?\[\/Context Passport\]/gi;
  var COMMENT_BLOCK_REGEX = /<!--\s*CONTEXT_PASSPORT_START[\s\S]*?CONTEXT_PASSPORT_END\s*-->/gi;
  var FALLBACK_BLOCK_REGEX = /<!-- Context-Passport[\s\S]*?-->/gi;
  function stripExtensionInjectedContext(text) {
    if (!text) return "";
    let cleaned = text.replace(INJECTION_BLOCK_REGEX, "");
    cleaned = cleaned.replace(COMMENT_BLOCK_REGEX, "");
    cleaned = cleaned.replace(FALLBACK_BLOCK_REGEX, "");
    return cleaned.trim();
  }
  function formatMemoryBlock(generalMemories = [], sensitiveMemories = [], preferences = []) {
    const parts = [];
    const allMemories = [...generalMemories, ...sensitiveMemories];
    if (allMemories.length > 0) {
      parts.push("Relevant Memories:");
      for (const mem of allMemories) {
        const clean = mem.text.trim();
        if (clean) {
          parts.push(`- ${clean}`);
        }
      }
    }
    if (preferences.length > 0) {
      if (parts.length > 0) parts.push("");
      parts.push("User Response Preference:");
      for (const pref of preferences) {
        const clean = pref.preference_text.trim();
        if (clean) {
          parts.push(`- ${clean}`);
        }
      }
    }
    if (parts.length === 0) {
      return "";
    }
    return `${INJECTION_START_MARKER}
${parts.join("\n")}
${INJECTION_END_MARKER}

`;
  }
  function applyMemoryBlockToDraft(currentDraft, newBlock) {
    const cleanDraftWithoutOldBlock = stripExtensionInjectedContext(currentDraft);
    if (!newBlock || newBlock.trim() === "") {
      return cleanDraftWithoutOldBlock;
    }
    if (cleanDraftWithoutOldBlock.length > 0) {
      return `${newBlock.trim()}

${cleanDraftWithoutOldBlock}`;
    }
    return newBlock.trim();
  }

  // src/core/screener.ts
  var SECRET_PATTERNS = [
    { name: "Private Key", pattern: /-----BEGIN[ A-Z0-9_-]*PRIVATE KEY-----/ },
    { name: "Google API Key", pattern: /AIza[0-9A-Za-z-_]{35}/ },
    { name: "OpenAI API Key", pattern: /sk-[a-zA-Z0-9_-]{20,}/ },
    { name: "Anthropic API Key", pattern: /sk-ant-[a-zA-Z0-9_-]{20,}/ },
    { name: "Supabase Secret Token", pattern: /sbp_[a-zA-Z0-9]{20,}/ },
    { name: "GitHub Token", pattern: /(?:gh[pousr]_[A-Za-z0-9_]{36,}|github_pat_[0-9a-zA-Z_]{82})/ },
    { name: "AWS Access Key", pattern: /AKIA[0-9A-Z]{16}/ },
    // Generic API key assignments: e.g. api_key=xyz, api-key: "xyz", access_token: xyz (quoted or unquoted)
    {
      name: "Generic API Key Assignment",
      pattern: /(?:\bapi[_-]?key|\bsecret[_-]?key|\baccess[_-]?token|\bauth[_-]?token)\s*[:=]\s*['"]?([a-zA-Z0-9_\-\.]{12,})['"]?/i
    },
    // Generic password assignments: e.g. password: xyz, password is xyz, passwd=xyz, pwd: 'xyz' (quoted or unquoted)
    {
      name: "Generic Password Assignment",
      pattern: /(?:\bpassword|\bpasswd|\bpwd)\s*(?:[:=]|\bis\b)\s*['"]?([^\s'"]{6,})['"]?/i
    },
    // Bearer Token
    { name: "Bearer Token Assignment", pattern: /\bBearer\s+([a-zA-Z0-9_\-\.]{12,})/i },
    // Financial numbers
    { name: "Credit Card Number", pattern: /\b(?:\d{4}[ -]?){3}\d{4}\b/ },
    { name: "Social Security Number", pattern: /\b\d{3}-\d{2}-\d{4}\b/ }
  ];
  var SENSITIVE_PATTERNS = [
    {
      name: "Allergy and Health Sensitivity",
      pattern: /\b(allergy|allergies|allergic|peanut|peanuts|epipen|anaphylaxis|gluten allergy|dairy allergy|nut allergy|shellfish allergy)\b/i
    },
    {
      name: "Medical Condition",
      pattern: /\b(medical condition|diagnosis|diagnosed with|prescription|medication|doctor's note|health record|bipolar|depression|cancer|hiv|pregnancy|addiction|diabetes|hospitalized)\b/i
    },
    {
      name: "Financial and Confidential",
      pattern: /\b(salary|income|bank account|routing number|credit score|passport number|social security|confidential project|strictly confidential|under nda|proprietary|tax return)\b/i
    },
    {
      name: "Identity and Contact Info",
      pattern: /\b(government id|national id|aadhaar|pan number|driver'?s license number|home address|street address|mailing address|phone number|mobile number|personal email|religion|religious belief|sexual orientation|gender identity|political affiliation|date of birth|birthday|legal name)\b/i
    },
    { name: "Email Address", pattern: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i },
    { name: "Personal Address", pattern: /\b(?:my|our|home|live at|reside at)\b.{0,30}\b\d{1,6}\s+[A-Za-z0-9 .'-]{2,50}\b(?:street|st\.?|road|rd\.?|avenue|ave\.?|lane|ln\.?|drive|dr\.?|boulevard|blvd\.?)\b/i },
    { name: "Phone Number", pattern: /\b(?:my|call me at|reach me at|phone(?: number)? is)\b.{0,25}(?:\+?\d[\d .()\-]{8,}\d)\b/i },
    { name: "Religious Identity", pattern: /\b(?:i am|i'm|my faith is)\s+(?:a\s+)?(?:buddhist|christian|muslim|hindu|jewish|sikh|atheist)\b/i },
    {
      name: "Uncertain / Speculative Fact",
      pattern: /\b(uncertain|not sure if|unconfirmed|tentative|provisional|speculative)\b/i
    }
  ];
  function containsSecret(text) {
    if (!text) return false;
    return SECRET_PATTERNS.some((p) => p.pattern.test(text));
  }
  function containsSensitive(text) {
    if (!text) return false;
    return SENSITIVE_PATTERNS.some((p) => p.pattern.test(text));
  }
  function screenText(text) {
    if (!text || text.trim() === "") {
      return { classification: "general" };
    }
    for (const { name, pattern } of SECRET_PATTERNS) {
      if (pattern.test(text)) {
        return {
          classification: "secret",
          reason: "Recognizable credential or secret detected and skipped completely",
          matchedPattern: name
        };
      }
    }
    for (const { name, pattern } of SENSITIVE_PATTERNS) {
      if (pattern.test(text)) {
        return {
          classification: "sensitive",
          reason: "Contains sensitive or personal attribute requiring explicit approval",
          matchedPattern: name
        };
      }
    }
    return { classification: "general" };
  }

  // src/core/capture.ts
  var normalize = (text) => text.replace(/\s+/g, " ").trim();
  var CaptureGate = class {
    pending = [];
    arm(draft, eventId, now = Date.now()) {
      const text = normalize(stripExtensionInjectedContext(draft));
      if (!text || containsSecret(text)) return false;
      this.pending = this.pending.filter((item) => now - item.createdAt < 3e4);
      if (this.pending.some((item) => item.text === text && now - item.createdAt < 750)) return true;
      this.pending.push({ text, eventId, createdAt: now });
      return true;
    }
    take(renderedText, now = Date.now()) {
      const text = normalize(stripExtensionInjectedContext(renderedText));
      this.pending = this.pending.filter((item) => now - item.createdAt < 3e4);
      const index = this.pending.findIndex((item) => item.text === text);
      if (index < 0) return null;
      return this.pending.splice(index, 1)[0].eventId;
    }
    clear() {
      this.pending = [];
    }
  };
  var SITE_ORIGIN_MAP = {
    chatgpt: "chatgpt.com",
    claude: "claude.ai",
    gemini: "gemini.google.com"
  };
  var SiteCaptureController = class {
    adapter;
    enabled;
    onCapture;
    gate;
    debounceMs;
    unsubscribeObserver = null;
    isDestroyed = false;
    handleSubmit;
    handleKeyDown;
    handleClick;
    constructor(options) {
      this.adapter = options.adapter;
      this.enabled = options.initialEnabled ?? false;
      this.onCapture = options.onCapture;
      this.debounceMs = options.debounceMs;
      this.gate = new CaptureGate();
      this.handleSubmit = (event) => {
        const composer = this.adapter.getComposer();
        if (composer && event.target instanceof Element && event.target.contains(composer)) {
          this.recordSend();
        }
      };
      this.handleKeyDown = (event) => {
        const composer = this.adapter.getComposer();
        if (composer && event.key === "Enter" && !event.shiftKey && !event.isComposing && event.target instanceof Node && (composer === event.target || composer.contains(event.target))) {
          this.recordSend();
        }
      };
      this.handleClick = (event) => {
        const target = event.target;
        if (!(target instanceof Element)) return;
        const button = target.closest("button");
        if (!button || button.classList.contains("context-passport-btn")) return;
        const label = `${button.getAttribute("aria-label") || ""} ${button.getAttribute("data-testid") || ""} ${button.textContent || ""} ${button.querySelector("[aria-label]")?.getAttribute("aria-label") || ""}`;
        const isSendButton = button.matches('button[type="submit"], button.send-button, [data-testid="send-button"], button[aria-label*="Send" i], button[aria-label*="send" i]') || /\b(send|submit|run prompt)\b/i.test(label);
        if (isSendButton) {
          this.recordSend();
        }
      };
      if (typeof document !== "undefined") {
        document.addEventListener("submit", this.handleSubmit, true);
        document.addEventListener("keydown", this.handleKeyDown, true);
        document.addEventListener("click", this.handleClick, true);
      }
      this.unsubscribeObserver = this.adapter.observeUserMessages(async (msg) => {
        if (!this.enabled || this.isDestroyed) return;
        const cleanText = stripExtensionInjectedContext(msg.text).trim();
        if (!cleanText) return;
        const screenResult = screenText(msg.text);
        if (screenResult.classification === "secret" || containsSecret(cleanText)) {
          return;
        }
        const eventId = this.gate.take(msg.text);
        if (!eventId) return;
        const sourceSite = SITE_ORIGIN_MAP[this.adapter.name] || "chatgpt.com";
        await this.onCapture({
          conversation_id: msg.conversationId,
          text: cleanText,
          role: "user",
          is_extension_context: false,
          event_id: eventId,
          source_site: sourceSite
        });
      }, this.debounceMs ? { debounceMs: this.debounceMs } : void 0);
    }
    isEnabled() {
      return this.enabled;
    }
    setEnabled(enabled) {
      this.enabled = enabled;
      if (!enabled) {
        this.gate.clear();
      }
    }
    recordSend() {
      if (!this.enabled || this.isDestroyed) return false;
      const draft = this.adapter.getComposerDraft();
      const eventId = typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `event-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
      return this.gate.arm(draft, eventId);
    }
    destroy() {
      this.isDestroyed = true;
      if (typeof document !== "undefined") {
        document.removeEventListener("submit", this.handleSubmit, true);
        document.removeEventListener("keydown", this.handleKeyDown, true);
        document.removeEventListener("click", this.handleClick, true);
      }
      if (this.unsubscribeObserver) {
        this.unsubscribeObserver();
        this.unsubscribeObserver = null;
      }
      this.gate.clear();
    }
  };

  // src/core/recall.ts
  function screenRecall(response) {
    const general = [];
    const sensitive = [];
    for (const memory of [...response.general_memories || [], ...response.sensitive_memories || []]) {
      if (!memory.text || memory.classification === "secret" || containsSecret(memory.text)) continue;
      if (memory.classification === "sensitive" || (response.sensitive_memories || []).includes(memory) || containsSensitive(memory.text)) {
        sensitive.push(memory);
      } else {
        general.push(memory);
      }
    }
    const preferences = (response.preferences || []).filter((pref) => Boolean(pref.preference_text) && !containsSecret(pref.preference_text) && !containsSensitive(pref.preference_text));
    return { general: general.slice(0, 3), sensitive, preferences };
  }

  // src/core/recallController.ts
  function escapeHtml(str) {
    if (!str) return "";
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }
  function promptSensitiveApproval(sensitiveMemories) {
    return new Promise((resolve) => {
      if (typeof document === "undefined" || !document.body) {
        resolve(false);
        return;
      }
      const backdrop = document.createElement("div");
      backdrop.className = "cp-modal-backdrop";
      const itemsHtml = sensitiveMemories.map(
        (m) => `
        <div class="cp-sensitive-item">
          <span class="cp-sensitive-badge">Sensitive</span>
          <span>${escapeHtml(m.text)}</span>
        </div>`
      ).join("");
      backdrop.innerHTML = `
      <div class="cp-modal-card">
        <div class="cp-modal-header">
          <div class="cp-modal-icon">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
          </div>
          <div class="cp-modal-title">Privacy Firewall: Sensitive Context</div>
        </div>
        <div class="cp-modal-desc">
          Relevant sensitive memories were found for this prompt. Do you want to allow them once for this request?
        </div>
        <div class="cp-sensitive-preview">
          ${itemsHtml}
        </div>
        <div class="cp-modal-actions">
          <button type="button" class="cp-btn-secondary" id="cp-deny-btn">Don't use</button>
          <button type="button" class="cp-btn-primary" id="cp-allow-btn">Allow once</button>
        </div>
      </div>
    `;
      document.body.appendChild(backdrop);
      const cleanup = (allowed) => {
        backdrop.remove();
        resolve(allowed);
      };
      backdrop.querySelector("#cp-allow-btn")?.addEventListener("click", () => cleanup(true));
      backdrop.querySelector("#cp-deny-btn")?.addEventListener("click", () => cleanup(false));
    });
  }
  function showComposerFallbackUI(preparedText) {
    if (typeof document === "undefined" || !document.body) {
      return null;
    }
    const existing = document.getElementById("cp-composer-fallback-backdrop");
    if (existing) existing.remove();
    const backdrop = document.createElement("div");
    backdrop.id = "cp-composer-fallback-backdrop";
    backdrop.className = "cp-modal-backdrop cp-fallback-backdrop";
    backdrop.innerHTML = `
    <div class="cp-modal-card cp-fallback-card" role="dialog" aria-modal="true" aria-label="Manual Copy Fallback">
      <div class="cp-modal-header">
        <div class="cp-modal-icon cp-fallback-icon">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>
            <rect x="8" y="2" width="8" height="4" rx="1" ry="1"/>
          </svg>
        </div>
        <div class="cp-modal-title">Manual Copy Fallback</div>
      </div>
      <div class="cp-modal-desc">
        The site composer could not be controlled directly. Your prepared prompt with verified memory context is ready:
      </div>
      <div class="cp-fallback-body">
        <textarea class="cp-fallback-textarea" readonly rows="8">${escapeHtml(preparedText)}</textarea>
      </div>
      <div class="cp-modal-actions">
        <button type="button" class="cp-btn-secondary" id="cp-fallback-dismiss-btn">Dismiss</button>
        <button type="button" class="cp-btn-primary" id="cp-fallback-copy-btn">Copy to Clipboard</button>
      </div>
    </div>
  `;
    document.body.appendChild(backdrop);
    const copyBtn = backdrop.querySelector("#cp-fallback-copy-btn");
    const dismissBtn = backdrop.querySelector("#cp-fallback-dismiss-btn");
    const textarea = backdrop.querySelector(".cp-fallback-textarea");
    copyBtn?.addEventListener("click", async () => {
      try {
        if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(preparedText);
        } else if (textarea) {
          textarea.select();
          document.execCommand("copy");
        }
        if (copyBtn) copyBtn.textContent = "Copied!";
        setTimeout(() => {
          backdrop.remove();
        }, 1200);
      } catch {
        if (copyBtn) copyBtn.textContent = "Failed to copy";
      }
    });
    dismissBtn?.addEventListener("click", () => {
      backdrop.remove();
    });
    return backdrop;
  }
  function showErrorToast(message) {
    if (typeof document === "undefined" || !document.body) {
      return null;
    }
    const existing = document.getElementById("cp-error-toast");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = "cp-error-toast";
    toast.className = "cp-error-toast";
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.remove();
    }, 3500);
    return toast;
  }
  async function handleUseMemoryAction(options) {
    const { adapter, apiClient, button } = options;
    if (button.disabled) return { success: false, reason: "draft_changed" };
    button.disabled = true;
    const btnLabel = button.querySelector("span");
    const currentDraft = adapter.getComposerDraft();
    const cleanDraft = stripExtensionInjectedContext(currentDraft).trim();
    if (cleanDraft && containsSecret(cleanDraft)) {
      if (btnLabel) btnLabel.textContent = "Secret in prompt!";
      button.disabled = false;
      button.classList.remove("loading");
      if (options.onError) {
        options.onError(new Error("Secret in prompt"));
      } else {
        showErrorToast("Context Passport: Recognizable secret detected in prompt. Memory recall cancelled for privacy.");
      }
      setTimeout(() => {
        if (btnLabel && btnLabel.textContent === "Secret in prompt!") {
          btnLabel.textContent = "Use Memory";
        }
      }, 2500);
      return { success: false, reason: "secret_detected" };
    }
    try {
      if (btnLabel) btnLabel.textContent = "Recalling...";
      button.classList.add("loading");
      const query = cleanDraft || "General user preferences and active context";
      const response = await apiClient.queryMemories(query, 3);
      const { general: finalGeneral, sensitive: sensitiveCandidates, preferences } = screenRecall(response);
      if (finalGeneral.length === 0 && sensitiveCandidates.length === 0 && preferences.length === 0) {
        adapter.setComposerDraft(stripExtensionInjectedContext(adapter.getComposerDraft()));
        if (btnLabel) btnLabel.textContent = "No memories found";
        button.classList.remove("loading");
        button.disabled = false;
        setTimeout(() => {
          if (btnLabel && btnLabel.textContent === "No memories found") {
            btnLabel.textContent = "Use Memory";
          }
        }, 2e3);
        return {
          success: true,
          preparedPrompt: cleanDraft,
          reason: "no_memories",
          generalCount: 0,
          approvedSensitiveCount: 0
        };
      }
      let approvedSensitive = [];
      if (sensitiveCandidates.length > 0) {
        const promptFn = options.onSensitivePrompt || promptSensitiveApproval;
        const allowed = await promptFn(sensitiveCandidates);
        if (allowed) {
          approvedSensitive = sensitiveCandidates;
        }
      }
      const memoryBlock = formatMemoryBlock(finalGeneral, approvedSensitive, preferences);
      const latestDraft = stripExtensionInjectedContext(adapter.getComposerDraft()).trim();
      if (latestDraft !== cleanDraft) {
        adapter.setComposerDraft(latestDraft);
        if (btnLabel) btnLabel.textContent = "Draft changed\u2014retry";
        button.classList.remove("loading");
        button.disabled = false;
        setTimeout(() => {
          if (btnLabel && btnLabel.textContent === "Draft changed\u2014retry") {
            btnLabel.textContent = "Use Memory";
          }
        }, 2e3);
        return { success: false, reason: "draft_changed" };
      }
      const updatedComposerText = applyMemoryBlockToDraft(latestDraft, memoryBlock);
      adapter.setComposerDraft(updatedComposerText);
      await new Promise((resolve) => setTimeout(resolve, 50));
      const composer = adapter.getComposer();
      const currentComposerText = adapter.getComposerDraft();
      const isComposerUpdated = Boolean(composer) && currentComposerText.trim() === updatedComposerText.trim();
      if (!isComposerUpdated) {
        if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
          try {
            await navigator.clipboard.writeText(updatedComposerText);
          } catch {
          }
        }
        if (options.onFallback) {
          options.onFallback(updatedComposerText);
        } else {
          showComposerFallbackUI(updatedComposerText);
        }
        if (btnLabel) btnLabel.textContent = "Copied to clipboard";
        button.classList.remove("loading");
        button.disabled = false;
        setTimeout(() => {
          if (btnLabel && btnLabel.textContent === "Copied to clipboard") {
            btnLabel.textContent = "Use Memory";
          }
        }, 2500);
        return {
          success: true,
          preparedPrompt: updatedComposerText,
          fallbackTriggered: true,
          generalCount: finalGeneral.length,
          approvedSensitiveCount: approvedSensitive.length,
          reason: "attached"
        };
      }
      if (btnLabel) btnLabel.textContent = "Attached!";
      button.classList.remove("loading");
      button.disabled = false;
      setTimeout(() => {
        if (btnLabel && btnLabel.textContent === "Attached!") {
          btnLabel.textContent = "Use Memory";
        }
      }, 2e3);
      return {
        success: true,
        preparedPrompt: updatedComposerText,
        fallbackTriggered: false,
        generalCount: finalGeneral.length,
        approvedSensitiveCount: approvedSensitive.length,
        reason: "attached"
      };
    } catch (err) {
      const rawMsg = err?.message || "Backend error";
      const isAuthErr = /HTTP 401|HTTP 403|token_expired/i.test(rawMsg);
      if (btnLabel) btnLabel.textContent = isAuthErr ? "Sign in again" : "Backend error";
      button.classList.add("cp-btn-error");
      button.classList.remove("loading");
      button.disabled = false;
      if (options.onError) {
        options.onError(err);
      } else {
        const userMsg = isAuthErr ? "Your session expired. Please open the Context Passport side panel and sign in again." : `Failed to retrieve memories. ${rawMsg}`;
        showErrorToast(`Context Passport: ${userMsg}`);
      }
      setTimeout(() => {
        if (btnLabel && (btnLabel.textContent === "Backend error" || btnLabel.textContent === "Sign in again")) {
          btnLabel.textContent = "Use Memory";
          button.classList.remove("cp-btn-error");
        }
      }, 3e3);
      return { success: false, reason: isAuthErr ? "auth_required" : "backend_error" };
    }
  }

  // src/content/index.ts
  async function init() {
    const adapter = getMatchingAdapter();
    if (!adapter) {
      return;
    }
    const settings = await getAllSettings();
    const apiClient = new ContextPassportApiClient(settings.backend_url, settings.auth_token);
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local") {
          if (changes.backend_url) {
            apiClient.setBackendUrl(changes.backend_url.newValue);
          }
          if (changes.auth_token) {
            apiClient.setToken(changes.auth_token.newValue);
          }
        }
      });
    }
    mountUseMemoryButton(adapter, apiClient);
    setupCaptureObserver(adapter, apiClient, settings[`capture_${adapter.name}`]);
  }
  function mountUseMemoryButton(adapter, apiClient) {
    const tryAttach = () => {
      const existing = document.querySelector(".context-passport-action-container");
      if (existing && existing.isConnected) return;
      const composer = adapter.getComposer();
      if (!composer) return;
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "context-passport-btn";
      btn.innerHTML = `
      <svg viewBox="0 0 24 24">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
      </svg>
      <span>Use Memory</span>
    `;
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        e.stopPropagation();
        await handleUseMemory(adapter, apiClient, btn);
      });
      adapter.attachUseMemoryButton(btn);
    };
    tryAttach();
    const domObserver = new MutationObserver(() => {
      tryAttach();
    });
    domObserver.observe(document.body, { childList: true, subtree: true });
    setInterval(tryAttach, 2e3);
  }
  async function handleUseMemory(adapter, apiClient, btn) {
    await handleUseMemoryAction({
      adapter,
      apiClient,
      button: btn
    });
  }
  function setupCaptureObserver(adapter, apiClient, initiallyEnabled) {
    const controller = new SiteCaptureController({
      adapter,
      initialEnabled: initiallyEnabled ?? false,
      onCapture: async (payload) => {
        try {
          await apiClient.ingestMessage(payload);
          console.info(`[Context Passport] Successfully ingested message for ${adapter.name}`);
        } catch (err) {
          console.warn("[Context Passport] Message ingestion failed:", err);
        }
      }
    });
    if (typeof chrome !== "undefined" && chrome?.storage?.onChanged) {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local") return;
        const change = changes[`capture_${adapter.name}`];
        if (!change) return;
        controller.setEnabled(change.newValue === true);
      });
    }
    return controller;
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
//# sourceMappingURL=content.js.map
