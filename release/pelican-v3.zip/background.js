// src/background/index.ts
if (typeof chrome !== "undefined" && chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error) => console.error("Error configuring side panel behavior:", error));
}
if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onInstalled) {
  chrome.runtime.onInstalled.addListener((details) => {
    console.log("Context Passport V3 installed successfully.");
    if (details.reason === "install") {
      chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") });
    }
  });
}
//# sourceMappingURL=background.js.map
